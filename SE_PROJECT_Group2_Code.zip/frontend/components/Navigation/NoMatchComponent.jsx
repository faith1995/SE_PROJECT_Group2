import React from 'react';

class NoMatchComponent extends React.Component {
    render() {
        return (
            <div className="container">
                No match
            </div>
        );
    }
}

export default NoMatchComponent;